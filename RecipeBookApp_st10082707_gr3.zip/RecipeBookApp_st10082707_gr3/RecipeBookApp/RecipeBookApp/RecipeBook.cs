﻿using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Navigation;

// ST10082707_PART1_PROG6221_3

namespace RecipeBookApp
{
    public partial class MainWindow : Window
    {
        private List<string> ingredients = new List<string>();

        private List<Recipes> recipesList = new List<Recipes>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddIngredient_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtIngredient.Text))
            {
                ingredients.Add(txtIngredient.Text);
                txtIngredient.Clear();
            }
        }

        private void btnAddRecipeDetails_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = txtRecipeName.Text;
            int calories;
            if (!int.TryParse(txtMaxCalories.Text, out calories))
            {
                MessageBox.Show("Please enter a valid number for calories.");
                return;
            }
            string foodGroups = ((ComboBoxItem)cmbFoodGroup.SelectedItem).Content.ToString();

            // You may need to collect the instructions in a similar manner
            List<string> instructions = new List<string>();

            Recipes recipe = new Recipes(recipeName, ingredients, instructions, calories, foodGroups);

            // Optionally do something with the newly created recipe, such as adding it to a list or displaying it
            MessageBox.Show("Recipe added successfully!");
            txtRecipeName.Clear();
            txtIngredient.Clear();
            txtMaxCalories.Clear();
            cmbFoodGroup.SelectedIndex = -1;
            ingredients.Clear();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            // Reset all fields
            txtRecipeName.Clear();
            txtIngredient.Clear();
            txtMaxCalories.Clear();
            cmbFoodGroup.SelectedIndex = -1;
            ingredients.Clear();
        }

        private void DisplayRecipes()
        {
            txtNewField.Text = "";

            foreach (var recipe in recipesList)
            {
                // Append recipe details to txtNewField
                txtNewField.Text += $"RECIPE: {recipe.recipeName}\n";
                txtNewField.Text += new string('=', 6) + "\n"; // Line separator

                // Append recipe details
                txtNewField.Text += $"Name: {recipe.recipeName}\n";
                txtNewField.Text += $"Ingredients: {string.Join(", ", recipe.ingredients)}\n";
                txtNewField.Text += $"Calories: {recipe.calories}\n";
                txtNewField.Text += $"Food Group: {recipe.foodGroups}\n";

                txtNewField.Text += new string('=', 6) + "\n\n"; // Line separator and extra line
            }
        }

        private void btnFilterRecipes_Click(object sender, RoutedEventArgs e)
        {
            //NavigationService?.Navigate(new DisplayRecipe());
        }
    }
}

//_________________________________________________END Part 2_______________________________________________________________________________