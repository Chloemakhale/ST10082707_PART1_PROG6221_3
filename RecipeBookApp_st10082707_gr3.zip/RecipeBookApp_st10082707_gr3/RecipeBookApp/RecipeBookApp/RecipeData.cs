﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBookApp
{
    internal class RecipeData
    {
        /// <summary>
        /// Class logic for Recipe object
        /// </summary>
        /// ---------------------------------------------------------------------------------------- //        
        public static class DataStore
        {
            public static List<Recipes> recipes { get; } = new List<Recipes>();
        }

        // ---------------------------------- 0oo0oo End of File oo0oo0 -------------------------------- //
    }
}
