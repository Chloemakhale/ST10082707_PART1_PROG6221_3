﻿using System.Collections.Generic;

namespace RecipeBookApp
{
    internal class Recipes
    {
        public string recipeName { get; set; }
        public List<string> ingredients { get; set; }
        public int calories { get; set; }
        public string foodGroups { get; set; }
        List<string> instructions { get; set; }

        public Recipes(string recipeName, List<string> ingredients, List<string> instructions, int calories, string foodGroups)
        {
            this.recipeName = recipeName;
            this.ingredients = ingredients;
            this.instructions = instructions;
            this.calories = calories;
            this.foodGroups = foodGroups;
        }
    }

}
