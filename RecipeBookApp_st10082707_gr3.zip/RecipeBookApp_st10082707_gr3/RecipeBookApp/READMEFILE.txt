NAME: Mohlao Makhale
ST10082707
PROG6221 PART 2
GROUP 3

instructions on how to compile and run the software:

continuing from the instructions i stated in part 1  of the the purpose of the software 
when you run the software the following will happen:

Adding a New Recipe
 
A USER WILL:
Choose option 1 to add a new recipe.
Enter the recipe name, number of ingredients, and instructions as prompted.
Provide details for each ingredient such as name, quantity, unit, calories, and food group.
Viewing Recipe Details:

Select option 2 to display all existing recipes along with their details.
You will see ingredients, quantities, measurements, calories, and food groups for each recipe.
Scaling a Recipe:

If you want to adjust the quantities of ingredients, choose option 3.
Enter the index of the recipe you want to scale and specify a scaling factor (0.5, 2, or 3).
Resetting a Recipe:

Option 4 allows you to reset the quantities of ingredients to their original values.
Enter the index of the recipe you want to reset.
Deleting a Recipe:

To remove a recipe entry, select option 5 and enter the index of the recipe you want to delete.
Exiting the Program:

Choose option 6 to exit the program when you are done.

The system provides error handling messages should the user not follow instructions 
the program calculates and displays the total calories of each recipe. if any recipe exceeds 300-calories a pop up message will be shown 
________________________________________________________________________________________
 part 2 :
This project allows users to enter, store, and manage recipes. It includes functionalities to display recipes in alphabetical order, calculate total calories, and ensure data integrity.

Improvements in Part 2
Based on feedback received, I have made several improvements to the project:

Error Fixes and Code Completion: I addressed the errors and completed any previously incomplete code sections to ensure full functionality.

Enhanced Functionalities:

Users can now enter an unlimited number of recipes.
Recipes are displayed in alphabetical order.
Total calories are displayed as whole numbers.
Improved User Experience:

The program remains active and does not exit unless the user inputs invalid data (e.g., adding decimals where not allowed).
Data Storage:

Recipes are now stored in a generic collection for better data management and retrieval.
Usage
Adding Recipes: Users can add as many recipes as they like.
Viewing Recipes: The list of recipes can be viewed in alphabetical order.
Calorie Calculation: The total calories for all recipes are shown as whole numbers.
How to Run
Clone the repository.
Navigate to the project directory.
Run the main program file.
___________________________________________________________________________________________
part 3 read me :
WPF_APP_POE is a graphical user interface (GUI) application built using Windows Presentation Foundation (WPF). This application serves as a recipe book, allowing users to add, view, and filter recipes based on specific criteria. The application is designed to be a more user-friendly version of a previously developed command line application.

Core Functionalities
Add Recipe: Users can add new recipes by entering the recipe name, ingredients, maximum calories, and selecting a food group.
View Recipes: Users can view all added recipes in a structured format.
Filter Recipes: Users can filter recipes based on:
Ingredient name
Food group
Maximum number of calories
Additional Features
Exit Application: Allows users to exit the application gracefully.
Cancel Operation: Allows users to cancel any ongoing operation and clear input fields.

Future Improvements
Implement more advanced filtering options.
Add functionality to edit and delete recipes.
Enhance the UI with more styles and animations. 
___________________________________________________________________________________________
git link: https://github.com/Chloemakhale/ST10082707_PART1_PROG6221_3/tree/prog6221-part2/ST10082707_PART1_PROG6221_3
https://github.com/Chloemakhale/ST10082707_PART1_PROG6221_3
